echo "Starting Nitrous..."
node cli.js --file user.txt 