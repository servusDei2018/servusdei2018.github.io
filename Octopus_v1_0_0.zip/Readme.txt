--Octopus v1.00

Octopus is a minimalistic code editor for JustBasic. http://servusdei2018.github.io

-Features:

	. Syntax highlighting
	. Code autocompletion
	. Tabbed file browsing

-Upcoming in v1.10:

	. View Menu
	
-Upcoming in v1.20:

	. Themes (changes syntax highlighting)
	. Ethereal mode (make code editor semi-transparent, useful for working on small screens)


--System Requirements:

	. Windows 7/8.1/10
	. .NET Framework (should already be present, you only need to worry about this if you get
	  an error message) 4+

