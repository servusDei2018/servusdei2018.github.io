--Octopus v1.10

Octopus is a minimalistic code editor for JustBasic. http://servusdei2018.github.io

-Features:

	. Syntax highlighting
	. Code autocompletion
	. Tabbed file browsing
	. View Menu
	. Ethereal Mode

-Upcoming in v1.20:

	. Themes (changes syntax highlighting)


--System Requirements:

	. Windows 7/8.1/10
	. .NET Framework (should already be present, you only need to worry about this if you get
	  an error message) 4+

